const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
canvas.width = 800;
canvas.height = 600;

let gameRunning = false;
let paused = false;
let score = 0;
let lives = 3;
let enemies = [];
let bullets = [];
let player = { x: 380, y: 550, width: 40, height: 40, speed: 5 };

function startGame() {
  document.getElementById("start-screen").classList.add("hidden");
  document.getElementById("game-over").classList.add("hidden");
  document.getElementById("pause-screen").classList.add("hidden");
  document.getElementById("game-ui").classList.remove("hidden");
  score = 0;
  lives = 3;
  enemies = [];
  bullets = [];
  gameRunning = true;
  paused = false;
  spawnEnemies();
  gameLoop();
}

function spawnEnemies() {
  setInterval(() => {
    if (!gameRunning || paused) return;
    let size = 30 + Math.random() * 20;
    enemies.push({ x: Math.random() * (canvas.width - size), y: -size, size: size, speed: 2 + score / 50 });
  }, 1000);
}

function gameLoop() {
  if (!gameRunning) return;
  if (!paused) {
    update();
    draw();
  }
  requestAnimationFrame(gameLoop);
}

function update() {
  bullets.forEach((b, i) => {
    b.y -= b.speed;
    if (b.y < 0) bullets.splice(i, 1);
  });

  enemies.forEach((e, i) => {
    e.y += e.speed;
    if (e.y > canvas.height) {
      enemies.splice(i, 1);
      lives--;
      if (lives <= 0) gameOver();
    }
    bullets.forEach((b, j) => {
      if (b.x < e.x + e.size && b.x + b.size > e.x && b.y < e.y + e.size && b.y + b.size > e.y) {
        enemies.splice(i, 1);
        bullets.splice(j, 1);
        score += 10;
      }
    });
  });

  document.getElementById("score").innerText = "Score: " + score;
  document.getElementById("lives").innerText = "Lives: " + lives;
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "lime";
  ctx.fillRect(player.x, player.y, player.width, player.height);
  ctx.fillStyle = "red";
  enemies.forEach(e => ctx.fillRect(e.x, e.y, e.size, e.size));
  ctx.fillStyle = "yellow";
  bullets.forEach(b => ctx.fillRect(b.x, b.y, b.size, b.size));
}

function shoot() {
  bullets.push({ x: player.x + player.width / 2 - 5, y: player.y, size: 10, speed: 7 });
}

function gameOver() {
  gameRunning = false;
  document.getElementById("game-ui").classList.add("hidden");
  document.getElementById("game-over").classList.remove("hidden");
  document.getElementById("final-score").innerText = "Final Score: " + score;
}

document.getElementById("start-btn").onclick = startGame;
document.getElementById("restart-btn").onclick = startGame;
document.getElementById("resume-btn").onclick = () => { paused = false; };
document.getElementById("quit-btn").onclick = () => {
  gameRunning = false;
  document.getElementById("pause-screen").classList.add("hidden");
  document.getElementById("start-screen").classList.remove("hidden");
};

document.addEventListener("keydown", e => {
  if (!gameRunning) return;
  if (e.key === "ArrowLeft" && player.x > 0) player.x -= player.speed;
  if (e.key === "ArrowRight" && player.x < canvas.width - player.width) player.x += player.speed;
  if (e.key === " " && !paused) shoot();
  if (e.key === "Escape") {
    paused = !paused;
    document.getElementById("pause-screen").classList.toggle("hidden", !paused);
  }
});
